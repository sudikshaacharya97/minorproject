<?php
	$conn= new mysqli('localhost','root','','miniproject');
	?>